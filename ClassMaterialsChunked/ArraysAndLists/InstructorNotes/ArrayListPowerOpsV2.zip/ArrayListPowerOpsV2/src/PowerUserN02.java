import java.util.ArrayList;
import java.util.function.Consumer;

/**
 * Example of how to use some of the power operations from ArrayList
 * @author CSSE Faculty
 *
 */
public class PowerUserN02 {
	
	private ArrayList<Car> allCars = new ArrayList<Car>();

	//--------------------------------------------------------------
	// Example uses the inner class Car
	//--------------------------------------------------------------

	/**
	 * Example class with some fields
	 * @author CSSE Faculty
	 *
	 */
	private class Car {
		private String name;
		private int age;
		
		//---------------------
		
		public Car(String name, int age) {
			super();
			this.name = name;
			this.age = age;
		} // Car
		
		//---------------------
		
		public void incrementOneYear() {
			this.age++;
		} // incrementOneYear

		//---------------------

		@Override
		public String toString() {
			return "(name=" + name + ", age=" + age + ")";
		} // toString		
	} // end class Car

	//--------------------------------------------------------------
	//--------------------------------------------------------------

	/**
	 * ensures: cars is loaded with some Car class objects
	 * @param cars
	 */
	private void loadCars(ArrayList<Car> cars) {
		String names[] = {"Mustang", "Rio", "Bronco"};
		int ages[] = {3, 0, 1};
		
		cars.clear();
		for (int k = 0; k < names.length; k++) {
			cars.add(new Car(names[k], ages[k]));
		} // end for	
	} // loadCars

	//--------------------------------------------------------------

	/**
	 * Example of how to use ArrayList's forEach operator
	 * Requires use of the Consumer interface and a lambda function
	 * @param cars
	 */
	private void ageUpOneYear(ArrayList<Car> cars) {
		Consumer<Car> ageUp = (c) -> {c.incrementOneYear();};
		cars.forEach(ageUp);
	} // ageUpOneYear

	//--------------------------------------------------------------

	/**
	 * Run all the operations above
	 */
	private void runApp() {		
		System.out.println(this.allCars);
		this.loadCars(allCars);
		this.ageUpOneYear(this.allCars);
		System.out.println(this.allCars);
	} // runApp

	//--------------------------------------------------------------

	/**
	 * main Java entry point
	 * @param args ignored
	 */
	public static void main(String[] args) {
		PowerUserN02 p1 = new PowerUserN02();
		p1.runApp();
	} // main

} // end class PowerUserN02

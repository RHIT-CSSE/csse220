import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;


public class PowerUserN01 {
	private Integer aOfIntV1[] = {0,1,2,3,4,5,6,7,8,9};
	private Integer aOfIntV2[] = {3,4,5};
	
	private ArrayList<Integer> fullArrayN01 = new ArrayList<Integer>(Arrays.asList(aOfIntV1));
	private ArrayList<Integer> fullArrayN02 = new ArrayList<Integer>(Arrays.asList(aOfIntV1));
	private ArrayList<Integer> partialArray = new ArrayList<Integer>(Arrays.asList(aOfIntV2));

	//--------------------------------------------------------------

	/**
	 * Example of how to use ArrayList's removeIf operation
	 * Requires use of the Predicate interface and a lambda function
	 * @param a1 array of integers
	 */
	private void removeEvens(ArrayList<Integer> a1) {
		Predicate<Integer> isEven = (k) -> (k % 2) == 0;
		a1.removeIf(isEven);
	} // removeEvens

	//--------------------------------------------------------------

	/**
	 * Example of how to use ArrayList's removeIf operation
	 * Requires use of the Predicate interface and a lambda function
	 * @param a1 array of integers
	 */
	private void removeOdds(ArrayList<Integer> a1) {
		Predicate<Integer> isOdd = (k) -> (k % 2) == 1;
		a1.removeIf(isOdd);
	} // removeOdds

	//--------------------------------------------------------------

	/**
	 * Example of how to use ArrayList's removeAll operation
	 * @param a1 array of integers
	 * @param a2 array of integers
	 */
	private void removeSome(ArrayList<Integer> a1, ArrayList<Integer> a2) {
		a1.removeAll(a2);
	} // removeSome

	//--------------------------------------------------------------
	
	private void addOneArrayListToAnother(ArrayList<Integer> a1, ArrayList<Integer> a2) {
		a1.addAll(a2);
	} // addOneArrayListToAnother

	//--------------------------------------------------------------

	/**
	 * Example of how to use ArrayList's replaceAll operation
	 * Requires use of the UnaryOperator interface and a lambda function
	 * @param a1 array of integers
	 */
	private void flipAllSigns(ArrayList<Integer> a1) {
		UnaryOperator<Integer> flipSign = (k) -> -k;
		a1.replaceAll(flipSign);
	} // flipAllSigns

	//--------------------------------------------------------------
	
	/**
	 * Example of how to use ArrayList's sort operation
	 * Requires use of the Comparator interface and a lambda function
	 * @param a1
	 */
	private void sortNonDecreasing(ArrayList<Integer> a1) {
		Comparator<Integer> isLE = (z1, z2) -> z1.compareTo(z2);
		a1.sort(isLE);
	} // sortNonDecreasing

	//--------------------------------------------------------------

	/**
	 * run all the operations above
	 */
	private void runApp() {
		System.out.println("a1: " + fullArrayN01 + " before removeEvens");
		this.removeEvens(fullArrayN01);
		System.out.println("a1: " + fullArrayN01 + " after removeEvens");
		System.out.println("--------------------------------------------------------------------");
		
		fullArrayN01.clear();
		fullArrayN01.addAll(fullArrayN02);		

		System.out.println("a1: " + fullArrayN01 + " before removeOdds");
		this.removeOdds(fullArrayN01);
		System.out.println("a1: " + fullArrayN01 + " after removeOdds");
		System.out.println("--------------------------------------------------------------------");
		
		fullArrayN01.clear();
		fullArrayN01.addAll(fullArrayN02);

		System.out.println("a1: " + fullArrayN01 + " before removeSome");
		this.removeSome(fullArrayN01, partialArray);
		System.out.println("a1: " + fullArrayN01 + " after removeSome");
		System.out.println("--------------------------------------------------------------------");
		

		System.out.println("a1: " + fullArrayN01 + " before addOneArrayListToAnother");
		this.addOneArrayListToAnother(fullArrayN01, partialArray);
		System.out.println("a1: " + fullArrayN01 + " after addOneArrayListToAnother");
		System.out.println("--------------------------------------------------------------------");
		
		fullArrayN01.clear();
		fullArrayN01.addAll(fullArrayN02);

		System.out.println("a1: " + fullArrayN01 + " before flipAllSigns");
		this.flipAllSigns(fullArrayN01);
		System.out.println("a1: " + fullArrayN01 + " after flipAllSigns");
		System.out.println("--------------------------------------------------------------------");
		
		System.out.println("a1: " + fullArrayN01 + " before sortNonDecreasing");
		this.sortNonDecreasing(fullArrayN01);
		System.out.println("a1: " + fullArrayN01 + " after sortNonDecreasing");
	} // runApp

	//--------------------------------------------------------------

	public static void main(String[] args) {
		PowerUserN01 p1 = new PowerUserN01();
		p1.runApp();
	} // main

}
